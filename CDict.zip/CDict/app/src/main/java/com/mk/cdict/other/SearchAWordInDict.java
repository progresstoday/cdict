package com.mk.cdict.other;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class SearchAWordInDict {

	String url = "https://dictionary.cambridge.org/dictionary/english/";
	String wordCss = "h2.headword";
	String definitionHeadCss = ".def-block > .def-head";
	String definitionCss = ".def";
	String exampleCss = ".eg";
	String ErrUnableToConnect = "Unable to reach dictionary.";
	String ErrNoWordFound = "Word definition is not found.";
	String retWord;
	HashMap<String,LinkedList<String>> retDefinitionAndExamplesMap;

	public String initSearch(String wordToSearch) {
		String msg = "Could not fetch the requested word.";
		if(wordToSearch!=null && !wordToSearch.isEmpty() && !"".equals(wordToSearch.trim())) {
			url = url+wordToSearch.trim().toLowerCase();
			System.err.println("url "+url);
			try {
				searchAWordInDictionary();
				msg = "success";
			} catch(Exception e) {
				msg = e.getMessage();
			}
		}
		return msg;
	}

	private void searchAWordInDictionary() throws Exception {
		Document doc = connectToDictionary();
		if(doc!=null) {
			String word = getSearchedWord(doc);
			System.err.println("word "+word);
			HashMap<String,LinkedList<String>> definitionAndExamplesMap = getWordDefinitionAndCorrespondingExamples(doc);
			retWord = word;
			retDefinitionAndExamplesMap = definitionAndExamplesMap;
		} else {
			System.out.println(ErrNoWordFound);
			throw new Exception(ErrNoWordFound);
		}
	}

	private Document connectToDictionary() throws Exception {
		Document doc = null;
		try {
			doc = Jsoup.connect(url).get();
		} catch(Exception e) {
			throw new Exception(ErrUnableToConnect);
		}
		return doc;
	}

	private String getSearchedWord(Document doc) throws Exception {
		String word = null;
		try {
			word = doc.selectFirst(wordCss).text();
		} catch(Exception e) {
			throw new Exception(ErrNoWordFound);
		}
		return word;
	}

	private HashMap<String,LinkedList<String>> getWordDefinitionAndCorrespondingExamples(Document doc) throws Exception {
		HashMap<String,LinkedList<String>> definitionAndExamplesMap = new LinkedHashMap<>();
		try {
			Elements definitionElements = doc.select(definitionHeadCss);
			for(Element currentDefinitionElement : definitionElements) {
				String definition = currentDefinitionElement.select(definitionCss).text();
				LinkedList<String> examplesList = new LinkedList<String>();
				for(Element exampleElement: currentDefinitionElement.parent().select(exampleCss)) {
					examplesList.add(exampleElement.text());
				}
				definitionAndExamplesMap.put(definition, examplesList);
			}
		} catch(Exception e) {
			throw new Exception(ErrNoWordFound);
		}
		return definitionAndExamplesMap;
	}

	public String getWord() {
		return retWord;
	}

	public HashMap<String,LinkedList<String>> getDefinitionAndMeaning() {
		return retDefinitionAndExamplesMap;
	}
}