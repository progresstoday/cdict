package com.mk.cdict;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.StrictMode;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TableLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.mk.cdict.other.SearchAWordInDict;
import java.util.HashMap;
import java.util.LinkedList;

public class MainActivity extends AppCompatActivity {

    static  {
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
    }

    Context ct = this;
    TableLayout table;
    String wordToSearch;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final EditText wordEditText = (EditText) findViewById(R.id.search_box);
        wordEditText.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if(event.getAction() == MotionEvent.ACTION_UP) {
                    if(event.getRawX() >= (wordEditText.getRight() - wordEditText.getCompoundDrawables()[2].getBounds().width())) {
                        System.out.println("Helloooooooooooooo");
                        EditText wordEditText = (EditText) findViewById(R.id.search_box);
                        wordEditText.setText("");
                        return true;
                    }
                }
                return false;
            }
        });

        ImageButton searchBtn = (ImageButton) findViewById(R.id.search_button);
        searchBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                searchListener();
            }
        });

        wordEditText.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if(actionId == EditorInfo.IME_ACTION_SEARCH) {
                    searchListener();
                }
                return false;
            }
        });
    }

    private void searchListener() {
        EditText wordEditText = (EditText) findViewById(R.id.search_box);
        wordToSearch = wordEditText.getText().toString();
        System.err.println("wordToSearch "+wordToSearch);
        if(wordToSearch!=null && !wordToSearch.isEmpty() && !"".equals(wordToSearch.trim())) {
            LinearLayout layout = (LinearLayout) findViewById(R.id.result_layout);
            layout.removeAllViewsInLayout();
            TextView wordTextView = new TextView(ct);
            wordTextView.setText("Loading..");
            wordTextView.setGravity(Gravity.CENTER);
            wordTextView.setTypeface(null, Typeface.BOLD);
            wordTextView.setPadding(0,30,0,30);
            layout.addView(wordTextView);
            searchWord();
        }
    }

    private void searchWord() {
        new Thread() {
            @Override
            public void run() {
                final SearchAWordInDict obj = new SearchAWordInDict();
                final String msg = obj.initSearch(wordToSearch);
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        LinearLayout layout = (LinearLayout) findViewById(R.id.result_layout);
                        layout.removeAllViewsInLayout();
                        if(msg.equalsIgnoreCase("success")) {
                            String word = obj.getWord();
                            HashMap<String, LinkedList<String>> definitionAndExamplesMap = obj.getDefinitionAndMeaning();

                            TextView wordTextView = new TextView(ct);
                            wordTextView.setText(word+":");
                            wordTextView.setTextSize(25.0f);
                            wordTextView.setTypeface(null, Typeface.BOLD_ITALIC);
                            wordTextView.setTextColor(Color.parseColor("#933a16"));
                            wordTextView.setPadding(0,30,30,50);
                            layout.addView(wordTextView);

                            for (String	definition : definitionAndExamplesMap.keySet()) {
                                if(definition!=null && !"".equals(definition)) {
                                    TextView meaningTV = new TextView(ct);
                                    meaningTV.setText(definition);
                                    meaningTV.setTextColor(Color.parseColor("#FFFFFF"));
                                    meaningTV.setBackgroundColor(Color.parseColor("#5f57c3"));
                                    meaningTV.setPadding(30,30,30,30);
                                    layout.addView(meaningTV);

                                    boolean bgColorChange = true;
                                    for(String example:definitionAndExamplesMap.get(definition)) {
                                        TextView exampleTV = new TextView(ct);
                                        exampleTV.setText(example);
                                        exampleTV.setTextColor(Color.parseColor("#000000"));
                                        if(bgColorChange) {
                                            exampleTV.setBackgroundColor(Color.parseColor("#e9e9e9"));
                                            bgColorChange = false;
                                        } else {
                                            exampleTV.setBackgroundColor(Color.parseColor("#d3d3d3"));
                                            bgColorChange = true;
                                        }
                                        exampleTV.setPadding(30,30,30,30);
                                        layout.addView(exampleTV);
                                    }

                                    TextView emptyTV = new TextView(ct);
                                    emptyTV.setText("");
                                    layout.addView(emptyTV);
                                }
                            }
                        } else {
                            TextView wordTextView = new TextView(ct);
                            wordTextView.setText(msg);
                            wordTextView.setTextColor(Color.parseColor("#ba160c"));
                            wordTextView.setPadding(0,30,0,30);
                            wordTextView.setGravity(Gravity.CENTER);
                            wordTextView.setTypeface(null, Typeface.BOLD);
                            layout.addView(wordTextView);
                        }
                    }
                });
            }
        }.start();
    }
}
